<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SacreBleuTileset" tilewidth="1538" tileheight="1026" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="512" height="512" source="white_tile.png"/>
 </tile>
 <tile id="1">
  <image width="512" height="512" source="gray_tile.png"/>
 </tile>
 <tile id="2">
  <image width="512" height="512" source="black_tile.png"/>
 </tile>
 <tile id="3">
  <image width="1538" height="878" source="cutting board 2.png"/>
 </tile>
 <tile id="4">
  <image width="1184" height="774" source="pan.png"/>
 </tile>
 <tile id="5">
  <image width="954" height="1026" source="stove burn 1.png"/>
 </tile>
</tileset>
